/**
 * 
 */

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * @author SiddhiVinayaka
 *
 */
public class MyGoogleChromeBrowser {
	
	public WebDriver DoUseGoogleChromeBrowser()
	{
		WebDriver driver = new ChromeDriver();
		return driver;
	}
	

}
